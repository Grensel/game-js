function toggleSound() {
    let toggleButton = document.querySelector('.toggle')
    toggleButton.classList.toggle('on');
}